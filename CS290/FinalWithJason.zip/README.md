Possible sites:
  Clicker (random movment week 1[Jason], click tracker week 1[Jeffery])
  (stautus effects week 2[Jason], helper 1 week 2[Jeffery])

